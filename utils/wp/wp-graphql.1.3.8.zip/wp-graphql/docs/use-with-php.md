---
uri: "/docs/use-with-php/"
title: "Use with PHP"
---

This document will be useful for users that want to use GraphQL within php files of their WordPress themes and plugins.
